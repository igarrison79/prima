# Prima Alpha sealed research record

**Author supplied record date:** 2026-11-19 (America/New_York).

This public package contains an encrypted research record and verification information. Its technical contents have intentionally **not** been disclosed by the public archive. The private key is NOT included and must NOT be uploaded.

- Encrypted capsule: `Prima_Alpha_Sealed_2026-11-19.enc.json`
- Encryption: AES-256-GCM, random 256-bit key and nonce; authenticated ciphertext.
- Plaintext ZIP SHA-256 commitment: `94b210a1ee0957b13e0d8e968230855a49dab1c50b1ae1eefc24ae5c5844f7d9`
- Ciphertext envelope SHA-256: `192e4482e25fb034439e2398681b9b79713dd09916e37a3fa8594b8897b58a58`
- Public recovery script: `decrypt_prima_capsule.py` (requires Python `cryptography`)

To demonstrate that a later-revealed plaintext is the same one committed here, decrypt the capsule and verify the plaintext ZIP hash. The Git hosting service's public commit provides a public date for this byte string. This is a commitment and chain-of-custody aid, not automatic patent protection, publication of the hidden technical contents, or independent certification of authorship.

**Publish only** `Prima_Alpha_Sealed_2026-11-19.enc.json`, this README, `PUBLIC_SHA256_2026-11-19.txt`, and `decrypt_prima_capsule.py`, or the public upload ZIP bundling those files. Never publish `PRIMA_PRIVATE_DECRYPTION_KEY.txt` or the PRIVATE statement.
