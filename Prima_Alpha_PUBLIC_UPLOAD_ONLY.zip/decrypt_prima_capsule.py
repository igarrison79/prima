#!/usr/bin/env python3
"""Decrypt a Prima Alpha research capsule. Requires pip install cryptography.
Usage: python decrypt_prima_capsule.py PUBLIC_CAPSULE.enc.json PRIMA_PRIVATE_DECRYPTION_KEY.txt OUTPUT_FOLDER
"""
from pathlib import Path
import base64,hashlib,io,json,re,sys,zipfile
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

def main():
    if len(sys.argv)!=4:
        raise SystemExit("Usage: python decrypt_prima_capsule.py CAPSULE.json PRIVATE_KEY.txt OUTPUT_FOLDER")
    env=json.loads(Path(sys.argv[1]).read_text())
    if env.get('format')!='prima-research-capsule-v1' or env.get('encryption')!='AES-256-GCM':
        raise SystemExit('Unrecognized capsule')
    match=re.search(r'AES-256-GCM key \(hex\): ([0-9a-f]{64})',Path(sys.argv[2]).read_text())
    if not match: raise SystemExit('Private key file not in expected format')
    key=bytes.fromhex(match.group(1))
    plain=AESGCM(key).decrypt(base64.b64decode(env['nonce_b64']),base64.b64decode(env['ciphertext_and_tag_b64']),env['aad_utf8'].encode())
    if hashlib.sha256(plain).hexdigest()!=env['plaintext_zip_sha256']:
        raise SystemExit('Plaintext hash mismatch')
    dest=Path(sys.argv[3]);dest.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(plain)) as z:
        for item in z.infolist():
            target=(dest/item.filename).resolve()
            if not target.is_relative_to(dest.resolve()): raise ValueError('Unsafe archive path')
            if item.is_dir(): continue
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(z.read(item))
            print('Decrypted:',target)
    print('Verified plaintext ZIP SHA256:', env['plaintext_zip_sha256'])
if __name__=='__main__': main()
